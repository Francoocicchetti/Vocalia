# Vocalia local OPUS decoder

Build on Apple Silicon with Apple command-line development tools: `sh build.sh`.
Bundled upstream sources come from https://downloads.xiph.org/releases/ogg/ and https://downloads.xiph.org/releases/opus/. SHA256SUMS pins the exact source archives. No model, recording or network service is required by this decoder. Libraries are statically linked; the helper depends only on libSystem. Each upstream archive includes its BSD license. Build output copies the licenses to licenses/ for distribution with the app.

Ogg Opus is decoded with libopusfile to temporary 48 kHz mono PCM WAV, respecting codec pre-skip and end trimming. The app then uses its existing audio pipeline and original timeline. Corrupt streams are rejected. The PCM copy is limited to ten hours and removed on normal app exit; recordings are never overwritten. Ogg/Vorbis is not supported by this helper.
