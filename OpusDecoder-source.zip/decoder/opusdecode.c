/* Vocalia local Ogg Opus decoder. Linked libraries retain their BSD licenses. */
#include <opus/opusfile.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
static int u16(FILE *f,uint16_t v){unsigned char b[2]={v&255,v>>8};return fwrite(b,1,2,f)==2;}
static int u32(FILE *f,uint32_t v){return u16(f,v&65535)&&u16(f,v>>16);}
static int header(FILE *f,uint32_t bytes){return fwrite("RIFF",1,4,f)==4&&u32(f,36+bytes)&&fwrite("WAVEfmt ",1,8,f)==8&&u32(f,16)&&u16(f,1)&&u16(f,1)&&u32(f,48000)&&u32(f,96000)&&u16(f,2)&&u16(f,16)&&fwrite("data",1,4,f)==4&&u32(f,bytes);}
int main(int argc,char **argv){
 if(argc!=3){fprintf(stderr,"Usage: opusdecode input.opus output.wav\n");return 2;}
 int error=0;OggOpusFile *of=op_open_file(argv[1],&error);
 if(!of){fprintf(stderr,"Invalid or unsupported Ogg Opus file (%d)\n",error);return 3;}
 opus_int64 total=op_pcm_total(of,-1);
 /* Bound output to ten hours and below the WAV 32-bit size ceiling. */
 if(total<=0||total>48000LL*36000){op_free(of);fprintf(stderr,"Invalid duration or OPUS recording over ten hours\n");return 4;}
 FILE *f=fopen(argv[2],"wb");if(!f){op_free(of);return 5;}
 int ok=header(f,0);uint32_t frames=0;opus_int16 stereo[11520];
 while(ok){
  int n=op_read_stereo(of,stereo,11520);
  if(n==0)break;
  if(n<0){ok=0;break;}
  if((uint64_t)frames+n>48000ULL*36000){ok=0;break;}
  for(int i=0;i<n;i++){int sample=((int)stereo[2*i]+(int)stereo[2*i+1])/2;if(!u16(f,(uint16_t)(int16_t)sample)){ok=0;break;}}
  frames+=n;
 }
 op_free(of);
 if(frames==0)ok=0;
 if(ok){if(fseek(f,0,SEEK_SET)!=0||!header(f,frames*2))ok=0;}
 if(fclose(f)!=0)ok=0;
 if(!ok){remove(argv[2]);fprintf(stderr,"Could not decode complete OPUS audio\n");return 6;}
 return 0;
}
