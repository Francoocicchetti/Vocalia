# Instalar Vocalia 1.0.1 en Mac

[English](INSTALL-MAC.md) · [Descargas](https://github.com/Francoocicchetti/Vocalia/releases/tag/v1.0.2)

## Compatibilidad

Requiere **Apple Silicon (M1 o posterior) y macOS 26 o posterior**. Compruébalo en el menú Apple → Acerca de este Mac. No funciona en MacBook Intel ni en versiones anteriores de macOS. Se descarga directamente; no se instala desde App Store.

## Descargar e instalar

1. Descarga **Vocalia-1.0.2-macOS-AppleSilicon.zip** desde la Release oficial de Vocalia en GitHub.
2. Abre el ZIP y arrastra **Vocalia.app** a **Aplicaciones**.
3. Abre Vocalia desde Aplicaciones.

## Si macOS no puede verificar al desarrollador

Vocalia tiene firma local, pero **no está notarizada por Apple**. Si confías en esta descarga y el Mac la bloquea:

1. Intenta abrir Vocalia una vez y cierra el aviso.
2. Entra a **Configuración del Sistema → Privacidad y seguridad**.
3. Busca el aviso de la app bloqueada y pulsa **Abrir igualmente**.
4. Autentícate si lo solicita y confirma **Abrir**.

Es la excepción por aplicación que documenta Apple; depende del aviso y de las políticas del equipo. No desactives Gatekeeper ni el antivirus. Si el aviso indica malware o daños, o el equipo administrado prohíbe excepciones, detente y consulta el aviso o al administrador. [Instrucciones oficiales de Apple](https://support.apple.com/es-cl/102445).

## Primera transcripción

Elige Español o English y después el idioma hablado. Pulsa **Descargar idioma** para preparar el modelo local de Apple. La comparación con Whisper y la separación de voces requieren sus propios modelos. Agrega grabaciones y transcribe los pendientes. Revisa el texto completo escuchando el original antes de publicar cuñas.

La descarga inicial de modelos necesita internet. Después el reconocimiento funciona localmente. Se conservan los originales y no se suben al preparar modelos. [Guía completa](GUIA.md) · [Privacidad](PRIVACY.es.md).

## Actualizar una versión de desarrollo

Cierra la app anterior y reemplaza Vocalia.app en Aplicaciones. Conserva la carpeta Application Support. El identificador y la ubicación del historial no cambian. **1.0 es la numeración pública**, que reemplaza etiquetas de desarrollo como 2.2.1; no borra tu historial. Conserva una copia de tus exportaciones importantes antes de actualizar.
