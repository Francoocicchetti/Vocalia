import Foundation

// UI text only. User transcripts, filenames and quotations are never translated.
enum AppLanguage {
    static let options: [(code:String,name:String)] = [("es","Español"),("en","English"),("de","Deutsch"),("fr","Français"),("zh","简体中文"),("pt","Português")]
    static func normalize(_ value:String)->String { let code=String(value.replacingOccurrences(of:"_",with:"-").split(separator:"-").first ?? "en"); return options.contains{$0.code==code} ? code : "en" }
    static var system:String { normalize(Locale.preferredLanguages.first ?? "en") }
    static var current:String {normalize(UserDefaults.standard.string(forKey:"uiLanguage") ?? system)}
    static let catalog:[String:[String:String]] = {
        let url=Bundle.main.url(forResource:"ui-translations",withExtension:"json") ?? URL(fileURLWithPath:#filePath).deletingLastPathComponent().appendingPathComponent("ui-translations.json")
        guard let data=try? Data(contentsOf:url),let result=try? JSONDecoder().decode([String:[String:String]].self,from:data) else{return [:]}
        return result
    }()
    static func interface(_ value:String,language:String)->String {catalog[value]?[normalize(language)] ?? value}
    static let english:[String:String]=[
        "Falta el decodificador OPUS. Descarga de nuevo la aplicación completa.": "The OPUS decoder is missing. Download the complete application again.",
        "No se pudo leer el archivo OPUS. Comprueba que no esté dañado y dure menos de diez horas.": "Could not read the OPUS file. Check that it is not damaged and is shorter than ten hours.",
        "¿Quitar esta transcripción del historial? El audio original se conserva.": "Remove this transcript from history? The original audio is kept.",
        "100 % local": "100% on device",
        "De la voz al texto. Dentro de tu Mac.": "From voice to text. On your Mac.",
        "Idioma del audio": "Audio language",
        "Interfaz": "App language",
        "Idioma listo": "Language ready",
        "Descargar idioma": "Download language",
        "Diccionario (%@)": "Dictionary (%@)",
        "GRABACIONES · %@": "RECORDINGS · %@",
        "Agregar archivos o carpetas…": "Add files or folders…",
        "Buscando archivos…": "Finding files…",
        "Agrega una grabación para empezar.": "Add a recording to get started.",
        "Nombres y siglas: Contraloría, COMPIN, Javiera Rodríguez…": "Names and acronyms: people, places, institutions…",
        "Separa términos con comas. Ayudan al reconocimiento; revisa nombres y cifras al terminar.": "Separate terms with commas. They help recognition; check names and figures when finished.",
        "Comparar con Whisper": "Compare with Whisper",
        "Separar voces": "Separate speakers",
        "Preparar modelos": "Prepare models",
        "Tus grabaciones, listas para leer.": "Your recordings, ready to read.",
        "Arrastra audios o videos. Obtén texto editable, marcas de tiempo y subtítulos.": "Drop audio or video files. Get editable text, timestamps and subtitles.",
        "Elegir archivos…": "Choose files…",
        "Transcribir pendientes": "Transcribe pending files",
        "Exportar todos los TXT": "Export all TXT files",
        "Quitar del historial…": "Remove from history…",
        "Quitar del historial": "Remove from history",
        "Cancelar": "Cancel",
        "Transcribir": "Transcribe",
        "Volver a transcribir": "Transcribe again",
        "Entendido": "OK",
        "Puedes agregar muchos archivos o carpetas de una vez, incluso mientras se procesa la cola.\nLos originales se conservan.": "Add multiple files or folders at once, even while the queue is running.\nOriginal files are kept.",
        "Velocidad": "Speed",
        "Vista de la transcripción": "Transcript view",
        "Texto completo": "Full text",
        "Revisar": "Review",
        "Cuñas": "Quotes",
        "Comparación": "Comparison",
        "Voces": "Speakers",
        "Analizar voces / comparar": "Analyze speakers / compare",
        "Copiar todo el texto": "Copy full text",
        "Exportar": "Export",
        "Vincular original…": "Relink original…",
        "Texto (.txt)": "Text (.txt)",
        "Subtítulos (.srt)": "Subtitles (.srt)",
        "TRANSCRIPCIÓN COMPLETA": "FULL TRANSCRIPT",
        "TEXTO PARCIAL · transcripción sin terminar": "PARTIAL TEXT · transcription unfinished",
        "Seguir audio": "Follow audio",
        "Guardar TXT": "Save TXT",
        "El amarillo sigue la voz. Puedes pausar, editar o seleccionar una cuña. Copiar todo incluye el texto entero.": "Yellow follows the voice. Pause, edit or select a quote. Copy full text includes the entire transcript.",
        "Escuchar selección": "Listen to selection",
        "Nombre del hablante": "Speaker name",
        "Guardar cuña": "Save quote",
        "No puedo ubicar esa selección con certeza. Elige una frase que coincida con el reconocimiento o revísala con audio.": "This selection cannot be located reliably. Choose text matching the original transcript or review it with audio.",
        "Tus cambios en este texto se guardan en el TXT. Los subtítulos conservan el texto de Revisar con audio.": "Your edits are saved in TXT. Subtitles use the text from the Review tab.",
        "Solo por revisar": "Only unreviewed",
        "Tienes una versión editada en Texto completo. Los cambios de estos fragmentos se aplican a los subtítulos; no reemplazan tu versión editada.": "You have edited the full text. Changes to these segments affect subtitles; they do not replace your edited full text.",
        "Escuchar y revisar": "Listen and review",
        "Hablante (opcional)": "Speaker (optional)",
        "Revisado": "Reviewed",
        "Otras lecturas": "Other readings",
        "Restaurar original": "Restore original",
        "Las marcas señalan baja confianza del motor, no una medición de precisión. Las etiquetas de voz se pueden revisar y renombrar.": "Marks indicate low recognition confidence, not measured accuracy. Speaker labels can be reviewed and renamed.",
        "Tu diccionario personal": "Your personal dictionary",
        "Guarda autoridades, comunas, apellidos e instituciones. Se usan como contexto, sin reemplazar palabras automáticamente.": "Save names, places and institutions. They provide context without automatically replacing words.",
        "Nombres o siglas separados por comas": "Names or acronyms separated by commas",
        "Guardar": "Save",
        "Se envían hasta 100 términos al motor en cada grabación. Whisper usa el contexto que cabe en su ventana de indicaciones.": "Up to 100 terms are passed to the local engine per recording. Whisper uses as much context as fits its prompt window.",
        "Listo": "Done",
        "Cuñas guardadas": "Saved quotes",
        "Exportar cuñas": "Export quotes",
        "Selecciona la cita en Texto completo y pulsa Guardar cuña. Se conserva exactamente lo seleccionado, con su origen y tiempo.": "Select text in Full text and choose Save quote. The exact selection is kept with its source and timing.",
        "Escuchar": "Listen",
        "Copiar cita": "Copy quote",
        "Copiar con fuente": "Copy with source",
        "Todavía no hay cuñas guardadas para esta grabación.": "No quotes have been saved for this recording yet.",
        "Solo diferencias": "Differences only",
        "Compara dos reconocimientos locales del mismo audio. Los bloques de unos 20 segundos resaltan diferencias; ninguna versión se considera automáticamente correcta.": "Compare two local transcripts of the same audio. Blocks of about 20 seconds highlight differences; neither version is assumed correct.",
        "Copiar versión completa de Whisper": "Copy full Whisper transcript",
        "Activa Comparar con Whisper y pulsa Analizar voces / comparar. La primera vez se descarga un modelo; luego funciona sin conexión.": "Enable Compare with Whisper and choose Analyze speakers / compare. A model is downloaded once, then runs offline.",
        "Voces y hablantes": "Voices and speakers",
        "El modelo agrupa voces como Voz 1, Voz 2… Tú les asignas nombres. Las etiquetas son propias de esta grabación y pueden confundirse si hay ruido o voces superpuestas.": "The model groups speakers as Voz 1, Voz 2… You can name them. Labels belong to this recording and may be incorrect with noise or overlapping speech.",
        "Cantidad de voces": "Number of speakers",
        "Cantidad": "Count",
        "Automática": "Automatic",
        "Si conoces cuántas personas hablan, indícalo antes de analizar. Recalcular voces puede cambiar las etiquetas.": "If you know the number of speakers, set it before analysis. Running speaker analysis again may change the labels.",
        "Activa Separar voces y pulsa Analizar voces / comparar.": "Enable Separate speakers and choose Analyze speakers / compare.",
        "Voz": "Speaker",
        "Elige una voz": "Choose a speaker",
        "Nombre de la persona": "Person’s name",
        "Asignar nombre": "Assign name",
        "Tu texto completo editado se conserva. Los nombres se aplican a los fragmentos y las cuñas guardadas.": "Your edited full text is preserved. Names apply to segments and saved quotes.",
        "Transcripción terminada": "Transcription complete",
        "Pendiente": "Pending",
        "En cola": "Queued",
        "Preparando audio": "Preparing audio",
        "Transcribiendo": "Transcribing",
        "Interrumpido · puedes volver a transcribir": "Interrupted · you can transcribe again",
        "No se detectó voz reconocible": "No recognizable speech detected",
        "Cancelado · se conserva el texto parcial": "Canceled · partial text kept",
        "Modelo %@ · listo en tu Mac": "Model %@ · ready on your Mac",
        "Modelo %@ · requiere descargar el idioma una vez": "Model %@ · one-time language download needed",
        "Whisper: descargado · Voces: descargado": "Whisper: downloaded · Speakers: downloaded",
        "Whisper: por descargar · Voces: por descargar": "Whisper: not downloaded · Speakers: not downloaded",
        "Whisper: descargado · Voces: por descargar": "Whisper: downloaded · Speakers: not downloaded",
        "Whisper: por descargar · Voces: descargado": "Whisper: not downloaded · Speakers: downloaded",
        "Comprobando el modelo de voz…": "Checking speech model…",
        "Modelos adicionales: comprobando…": "Additional models: checking…",
        "El reconocimiento local no está disponible en este Mac.": "Local speech recognition is unavailable on this Mac.",
        "Este idioma no está disponible en el motor local.": "This language is unavailable in the local engine.",
        "Descargando el modelo de idioma. Tus grabaciones no se envían.": "Downloading the language model. Your recordings are not uploaded.",
        "Idioma listo. Ya puedes transcribir sin conexión.": "Language ready. You can now transcribe offline.",
        "El idioma aún no está listo. Intenta descargarlo de nuevo.": "The language is not ready yet. Try downloading it again.",
        "Descarga cancelada.": "Download canceled.",
        "No se pudo preparar el idioma.": "Could not prepare the language.",
        "El idioma elegido no está disponible para transcripción local.": "The selected language is unavailable for local transcription.",
        "No hay espacio para reservar otro idioma. Revisa los idiomas de voz instalados en macOS.": "No room to reserve another language. Check the speech languages installed in macOS.",
        "No encuentro el audio original. Conecta el disco o usa Vincular original para elegirlo en su nueva ubicación.": "Original audio not found. Connect the drive or use Relink original to choose its new location.",
        "Transcripción completa copiada. Lista para pegar de una vez.": "Full transcript copied. Ready to paste in one go.",
        "Original vinculado. Tu texto y tus cuñas se conservan.": "Original relinked. Your text and saved quotes are preserved.",
        "Cuña guardada con su texto literal, archivo y tiempo.": "Quote saved with its exact text, source file and time.",
        "Cuña copiada.": "Quote copied.",
        "Cuñas exportadas.": "Quotes exported.",
        "Preparando el reconocimiento local…": "Preparing local recognition…",
        "Cancelando…": "Canceling…",
        "Los dos modelos adicionales están listos para trabajar sin conexión.": "Both additional models are ready to work offline.",
        "Preparación cancelada.": "Preparation canceled.",
        "No se pudieron preparar los modelos.": "Could not prepare models.",
        "Voces separadas automáticamente; revisa las etiquetas.": "Speakers separated automatically; review the labels.",
        "Comparación terminada. Las diferencias son puntos para revisar, no errores demostrados.": "Comparison complete. Differences are points to review, not proven errors.",
        "Preparando audio para comparación y voces…": "Preparing audio for comparison and speakers…",
        "Análisis adicional terminado. Abre Comparación o Voces.": "Additional analysis complete. Open Comparison or Speakers.",
        "Análisis adicional cancelado; tu transcripción se conserva.": "Additional analysis canceled; your transcript is preserved.",
        "No se pudo completar el análisis adicional.": "Could not complete additional analysis.",
        "Descargando Whisper para comparar dentro del Mac…": "Downloading Whisper to compare on your Mac…",
        "Descargando Whisper: %@ %": "Downloading Whisper: %@ %",
        "Preparando Whisper para este Mac…": "Preparing Whisper for this Mac…",
        "Descargando el modelo para separar voces…": "Downloading the speaker separation model…",
        "Preparando la separación de voces…": "Preparing speaker separation…",
        "Preparando los modelos de voces…": "Preparing speaker models…",
        "Modelos locales listos": "Local models ready",
        "Comparando con Whisper en tu Mac…": "Comparing with Whisper on your Mac…",
        "Separando voces: %@ %": "Separating speakers: %@ %",
        "Lote terminado: %@ archivos procesados. Revisa el estado de cada grabación.": "Batch complete: %@ files processed. Check each recording’s status.",
        "%@ archivos agregados. Selecciona Transcribir pendientes para procesarlos todos.": "%@ files added. Choose Transcribe pending files to process them all.",
        "Archivo %@ de %@": "File %@ of %@",
        "%@ palabras · %@": "%@ words · %@",
        "Selección: %@–%@ · tiempos del fragmento de origen": "Selection: %@–%@ · source segment timing",
        "%@ bloques con diferencias de %@": "%@ differing blocks out of %@",
        "Extrayendo el audio de %@…": "Extracting audio from %@…",
        "Transcribiendo en tu Mac · %@": "Transcribing on your Mac · %@",
        "Transcripción terminada. Revisa nombres, cifras y fragmentos señalados.": "Transcription complete. Review names, figures and marked segments.",
        "Guardado: %@": "Saved: %@",
        "Guardar transcripción": "Save transcript",
        "Guardar todos los TXT": "Save all TXT files",
        "Agregar a la cola": "Add to queue",
        "Selecciona varios archivos con ⌘ o Mayúsculas. También puedes elegir carpetas completas.": "Select multiple files with Command or Shift. You can also select entire folders.",
        "Vincular original": "Relink original",
        "Elige el mismo audio o video en su nueva ubicación. Los tiempos guardados corresponden a esa grabación.": "Choose the same audio or video in its new location. Saved timestamps refer to that recording.",
        "Escuchar el original": "Listen to original",
        "Transcripción completa editable": "Editable full transcript",
        "Quitar término": "Remove term",
        "Sin texto en este tramo": "No text in this section",
        "Sin asignar": "Unassigned",
        "El texto aparecerá aquí conforme se reconozca.": "Text will appear here as it is recognized.",
        "Pulsa Transcribir para convertir esta grabación en texto.": "Choose Transcribe to convert this recording to text.",
        "La transcripción aparecerá aquí como un solo texto.": "The transcript will appear here as a single text.",
        "Pulsa Transcribir para obtener el texto completo.": "Choose Transcribe to get the full text.",
        "Se quitará la transcripción y sus correcciones del historial. El archivo original no se elimina.": "The transcript and its edits will be removed from history. The original file is not deleted."
    ]
    static let templates:[(NSRegularExpression,String)]=english.compactMap { key,value in
        guard key.contains("%@") else{return nil}
        let pattern="^"+key.components(separatedBy:"%@").map{NSRegularExpression.escapedPattern(for:$0)}.joined(separator:"(.*?)")+"$"
        guard let regex=try? NSRegularExpression(pattern:pattern,options:[.dotMatchesLineSeparators]) else{return nil}
        return (regex,value)
    }
    static func translate(_ value:String,language:String)->String {
        guard language != "es" else{return value}
        if let exact=english[value]{return interface(exact,language:language)}
        let ns=value as NSString
        for (regex,target) in templates {
            guard let match=regex.firstMatch(in:value,range:NSRange(location:0,length:ns.length)) else{continue}
            let pieces=interface(target,language:language).components(separatedBy:"%@")
            guard pieces.count==match.numberOfRanges else{continue}
            var output=pieces[0]
            for i in 1..<pieces.count {output += ns.substring(with:match.range(at:i))+pieces[i]}
            return output
        }
        return value
    }
}
func L(_ value:String)->String {AppLanguage.translate(value,language:AppLanguage.current)}

func T(_ value:String)->String {AppLanguage.interface(value,language:AppLanguage.current)}
