"""First-run language choice and a replayable, local-only beginner guide."""
from PySide6.QtWidgets import QDialog, QVBoxLayout, QLabel, QComboBox, QPushButton, QHBoxLayout, QTextBrowser, QApplication

class WelcomeDialog(QDialog):
    def __init__(self, language='en', parent=None):
        super().__init__(parent)
        self.setWindowTitle('Vocalia');self.setMinimumWidth(560)
        self.resize(640, min(660, QApplication.primaryScreen().availableGeometry().height()-60))
        self.language=language;self.page=0
        layout=QVBoxLayout(self);layout.setSpacing(16)
        self.heading=QLabel('Welcome to Vocalia / Bienvenido a Vocalia')
        self.heading.setStyleSheet('font-size:21px;font-weight:700;color:#393368');self.heading.setWordWrap(True)
        layout.addWidget(self.heading)
        self.language_box=QComboBox();self.language_box.addItem('Español','es');self.language_box.addItem('English','en')
        self.language_box.setCurrentIndex(0 if language=='es' else 1);layout.addWidget(self.language_box)
        self.body=QTextBrowser();self.body.setPlainText('Choose your language before starting.\nElige tu idioma antes de comenzar.')
        self.body.setMinimumHeight(300);self.body.setStyleSheet('font-size:15px;line-height:1.5;padding:10px');layout.addWidget(self.body, 1)
        row=QHBoxLayout();layout.addLayout(row)
        self.back_button=QPushButton('Back / Atrás');self.back_button.hide();self.back_button.clicked.connect(self.back);row.addWidget(self.back_button)
        row.addStretch();self.next_button=QPushButton('Continue / Continuar');self.next_button.clicked.connect(self.advance);row.addWidget(self.next_button)
        self.setStyleSheet('QDialog{background:#f7f7fb} QPushButton,QComboBox{padding:9px}')

    def back(self):
        self.page=0;self.language_box.show();self.back_button.hide()
        self.heading.setText('Welcome to Vocalia / Bienvenido a Vocalia')
        self.body.setText('Choose your language before starting.\nElige tu idioma antes de comenzar.')
        self.next_button.setText('Continue / Continuar')

    def advance(self):
        if self.page==1:self.accept();return
        self.language=self.language_box.currentData();self.page=1;self.language_box.hide();self.back_button.show()
        es=self.language=='es'
        self.heading.setText('Tu primera transcripción' if es else 'Your first transcript')
        self.back_button.setText('Atrás' if es else 'Back')
        self.next_button.setText('Empezar a usar Vocalia' if es else 'Start using Vocalia')
        self.body.setText(
            '1. AGREGA TUS ARCHIVOS\nPulsa «Agregar archivos» y elige uno o varios audios o videos. Agregarlos no los transcribe todavía.\n\n'
            '2. ELIGE EL IDIOMA DEL AUDIO\nSelecciona el idioma que habla la persona. Puede ser distinto del idioma de los botones.\n\n'
            '3. PULSA «TRANSCRIBIR PENDIENTES»\nLa primera vez, acepta descargar el modelo. Necesitas internet y espacio disponible; al terminar, la transcripción empieza automáticamente. «small» es el modelo inicial.\n\n'
            '4. ESPERA EL TEXTO\nVerás «Preparando» o «Transcribiendo» y luego el texto completo. El botón «Reproducir / pausar» solo sirve para escuchar; no transcribe.\n\n'
            '5. REVISA Y COPIA\nRevisa nombres y cifras, pulsa «Copiar texto completo» o exporta TXT. Selecciona texto para guardar cuñas.\n\n'
            'Tus grabaciones se procesan en este equipo y se conservan. Después de descargar el modelo puedes transcribir sin internet. Puedes volver a abrir esta guía o cambiar el idioma dentro de Vocalia.'
            if es else
            '1. ADD YOUR FILES\nChoose “Add files” and select one or more recordings or videos. Adding files does not transcribe them yet.\n\n'
            '2. CHOOSE THE AUDIO LANGUAGE\nSelect the language the person speaks. It can differ from the language of the buttons.\n\n'
            '3. CLICK “TRANSCRIBE PENDING”\nOn first use, accept the model download. Internet and free disk space are needed; transcription starts automatically when it finishes. “small” is the starting model.\n\n'
            '4. WAIT FOR THE TEXT\nYou will see “Preparing” or “Transcribing”, followed by the full text. “Play / pause” only plays audio; it does not transcribe.\n\n'
            '5. REVIEW AND COPY\nReview names and numbers, then choose “Copy full text” or export TXT. Select a passage to save a quote.\n\n'
            'Recordings are processed on this computer and kept intact. After downloading the model you can transcribe offline. Reopen this guide or change the app language inside Vocalia.')
