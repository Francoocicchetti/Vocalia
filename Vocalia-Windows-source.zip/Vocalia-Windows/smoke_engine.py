"""Uses the public JFK fixture from the official OpenAI Whisper test suite. Can test either Python source or the packaged executable."""
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

with tempfile.TemporaryDirectory(prefix='VocaliaEngineTest-') as folder:
    root = Path(folder)
    models = Path(os.environ.get('VOCALIA_TEST_MODELS', str(root/'models'))).resolve()
    binary = sys.argv[1] if len(sys.argv)>1 else None
    command = [binary] if binary else [sys.executable, str(Path(__file__).with_name('app.py'))]
    for task in ['prepare','transcribe']:
        jobdir = root/task;jobdir.mkdir()
        job = dict(task=task, model='tiny', models=str(models), source=str(Path(__file__).with_name('test-speech.flac').resolve()), language='en', terms=[])
        jobfile=jobdir/'job.json';jobfile.write_text(json.dumps(job),encoding='utf-8')
        result=subprocess.run(command+['--worker',str(jobfile)],timeout=900)
        if result.returncode or not (jobdir/'result.json').exists():
            print((jobdir/'events.jsonl').read_text() if (jobdir/'events.jsonl').exists() else 'Worker produced no events')
            raise SystemExit('Engine worker failed')
        value=json.loads((jobdir/'result.json').read_text())
        if task=='transcribe':
            assert value['segments'] and value['duration']>0
            assert any(s.get('words') for s in value['segments'])
            text=' '.join(s['text'] for s in value['segments']).lower()
            assert 'country' in text, text
            print('PASS: public test audio transcribed with word timestamps')
