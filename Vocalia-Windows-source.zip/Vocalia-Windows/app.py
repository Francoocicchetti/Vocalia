"""Vocalia Windows preview. UI and storage stay outside the speech process."""
import json
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from collections import deque
from core import Store, new_document, transcript_text, timestamp, export_text, selection_match, playback_range, qt_index, python_index, atomic_json


def data_root():
    return Path(os.environ.get('LOCALAPPDATA', str(Path.home() / '.local' / 'share'))) / 'Vocalia'


def command(job):
    if getattr(sys, 'frozen', False):
        return [sys.executable, '--worker', str(job)]
    return [sys.executable, str(Path(__file__).resolve()), '--worker', str(job)]


ES = {
    'title': 'Vocalia · Windows', 'add': 'Agregar archivos', 'folder': 'Agregar carpeta',
    'run': 'Transcribir pendientes', 'cancel': 'Cancelar', 'remove': 'Quitar del historial',
    'undo': 'Recuperar última eliminada', 'language': 'Idioma del audio', 'interface': 'Interfaz',
    'model': 'Modelo local', 'prepare': 'Descargar / preparar modelo', 'ready': 'Modelo listo',
    'terms': 'Diccionario: nombres, lugares y siglas separados por comas',
    'text': 'Texto completo', 'quotes': 'Cuñas', 'copy': 'Copiar texto completo',
    'export': 'Exportar', 'batch_export': 'Exportar todos los TXT', 'play': 'Reproducir / pausar',
    'listen': 'Escuchar selección', 'save_quote': 'Guardar cuña', 'speaker': 'Nombre del hablante',
    'follow': 'Seguir audio', 'relink': 'Vincular original', 'quote_copy': 'Copiar cuña con fuente',
    'welcome': 'Agrega grabaciones. Todo se procesa en este equipo; los originales se conservan.',
    'pending': 'Pendiente', 'running': 'Transcribiendo', 'done': 'Terminada',
    'error': 'Error · puedes reintentar', 'partial': 'Parcial · cancelada o interrumpida',
    'loading': 'Preparando el modelo local…', 'transcribing': 'Transcribiendo en este equipo…',
    'model_missing': 'Prepara primero el modelo. La descarga no envía tus grabaciones.',
    'source_missing': 'No encuentro el original. Conecta el disco o pulsa Vincular original.',
    'invalid_selection': 'Selecciona una frase intacta de la transcripción para conservar sus tiempos.',
    'remove_confirm': '¿Quitar esta transcripción del historial? El audio se conserva y puedes recuperar la entrada.',
    'close_confirm': 'Hay un trabajo en curso. ¿Cancelarlo y cerrar? Se conserva el texto parcial.',
    'model_info': 'small: equilibrado · medium: mayor consumo · large-v3-turbo: más precisión, más memoria',
    'limitations': 'Windows: Whisper local; hablantes manuales en cuñas. Sin motor Apple ni separación automática de voces.',
    'saved': 'Guardado.', 'copied': 'Copiado.', 'finished': 'Cola terminada. Revisa nombres, cifras y citas.',
    'preparing': 'Descargando / preparando el modelo. Puedes cancelar.', 'scanning': 'Buscando archivos…',
    'export_note': 'TXT conserva tus ediciones. SRT/VTT usan los fragmentos originales con sus tiempos.',
    'errors': 'El proceso no pudo terminar. El resto del historial se conserva.',
}
EN = {
    'title': 'Vocalia · Windows', 'add': 'Add files', 'folder': 'Add folder',
    'run': 'Transcribe pending', 'cancel': 'Cancel', 'remove': 'Remove from history',
    'undo': 'Restore last removed', 'language': 'Audio language', 'interface': 'App language',
    'model': 'Local model', 'prepare': 'Download / prepare model', 'ready': 'Model ready',
    'terms': 'Dictionary: names, places and acronyms separated by commas',
    'text': 'Full text', 'quotes': 'Quotes', 'copy': 'Copy full text', 'export': 'Export',
    'batch_export': 'Export all TXT files', 'play': 'Play / pause', 'listen': 'Listen to selection',
    'save_quote': 'Save quote', 'speaker': 'Speaker name', 'follow': 'Follow audio',
    'relink': 'Relink original', 'quote_copy': 'Copy quote with source',
    'welcome': 'Add recordings. Processing stays on this computer; originals are preserved.',
    'pending': 'Pending', 'running': 'Transcribing', 'done': 'Complete', 'error': 'Error · retry available',
    'partial': 'Partial · canceled or interrupted', 'loading': 'Preparing the local model…',
    'transcribing': 'Transcribing on this computer…', 'model_missing': 'Prepare the model first. Downloads do not upload your recordings.',
    'source_missing': 'Original not found. Connect the drive or choose Relink original.',
    'invalid_selection': 'Select unchanged transcript text to preserve its source timing.',
    'remove_confirm': 'Remove this transcript? Original audio is kept and the entry can be restored.',
    'close_confirm': 'A job is running. Cancel it and close? Partial text will be preserved.',
    'model_info': 'small: balanced · medium: more resources · large-v3-turbo: higher accuracy, more memory',
    'limitations': 'Windows: local Whisper; manual speaker names in quotes. No Apple engine or automatic speaker separation.',
    'saved': 'Saved.', 'copied': 'Copied.', 'finished': 'Queue complete. Review names, numbers and quotes.',
    'preparing': 'Downloading / preparing the model. You can cancel.', 'scanning': 'Finding files…',
    'export_note': 'TXT preserves edits. SRT/VTT use original segments with timestamps.',
    'errors': 'The process could not finish. The rest of your history is preserved.',
}


def main(smoke=False):
    from PySide6.QtCore import Qt, QTimer, QUrl, QLockFile
    from PySide6.QtGui import QIcon, QTextCursor, QColor, QPixmap
    from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                                  QPushButton, QLabel, QListWidget, QListWidgetItem, QComboBox,
                                  QTextEdit, QLineEdit, QCheckBox, QTabWidget, QSplitter,
                                  QFileDialog, QMessageBox, QProgressBar, QSlider)
    from PySide6.QtMultimedia import QMediaPlayer, QAudioOutput

    app = QApplication(sys.argv[:1])
    app.setApplicationName('Vocalia')
    app.setOrganizationName('Vocalia')
    root = Path(tempfile.mkdtemp(prefix='VocaliaSmoke-')) if smoke else data_root()
    root.mkdir(parents=True, exist_ok=True)
    lock = QLockFile(str(root / 'instance.lock'))
    if not lock.tryLock(0):
        QMessageBox.information(None, 'Vocalia', 'Vocalia ya está abierta / Vocalia is already running.')
        return 0
    try:
        store = Store(root / 'history.sqlite3')
    except Exception as error:
        QMessageBox.critical(None, 'Vocalia', f'No se pudo abrir el historial / Could not open history:\n{error}')
        return 1

    class Window(QMainWindow):
        def __init__(self):
            super().__init__()
            self.store = store
            self.selected = None
            self.pending_edit = None
            self.proc = None
            self.job_dir = None
            self.job = None
            self.events_offset = 0
            self.event_error = ''
            self.queue = deque()
            self.cancelled = False
            self.play_until = None
            self.loaded_source = None
            self.last_highlight = None
            self.language = store.setting('ui_language', 'es')
            for doc in store.documents():
                if doc['status'] == 'running':
                    doc['status'] = 'partial'
                    store.save(doc)
            self.setMinimumSize(1000, 730)
            self.resize(1220, 840)
            central = QWidget()
            self.setCentralWidget(central)
            outer = QVBoxLayout(central)
            header = QHBoxLayout()
            image = QLabel()
            icon_path = Path(__file__).parent / 'logo.png'
            if icon_path.exists():
                image.setPixmap(QPixmap(str(icon_path)).scaled(58, 58, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
                self.setWindowIcon(QIcon(str(icon_path)))
            header.addWidget(image)
            title = QLabel('Vocalia');title.setStyleSheet('font-size:28px;font-weight:700;color:#292654')
            header.addWidget(title);header.addStretch()
            self.interface_label = QLabel();header.addWidget(self.interface_label)
            self.interface = QComboBox();self.interface.addItem('Español', 'es');self.interface.addItem('English', 'en')
            self.interface.setCurrentIndex(0 if self.language == 'es' else 1)
            header.addWidget(self.interface);outer.addLayout(header)
            splitter = QSplitter();outer.addWidget(splitter, 1)
            side = QWidget();left = QVBoxLayout(side);side.setMinimumWidth(245)
            self.buttons = {}
            def button(key, target, handler):
                obj = QPushButton();obj.clicked.connect(handler);target.addWidget(obj);self.buttons[key] = obj
                return obj
            button('add', left, self.add_files);button('folder', left, self.add_folder)
            self.list = QListWidget();left.addWidget(self.list, 1)
            button('run', left, self.begin);button('batch_export', left, self.export_all)
            button('remove', left, self.remove_doc);button('undo', left, self.undo_remove)
            splitter.addWidget(side)
            content = QWidget();right = QVBoxLayout(content);splitter.addWidget(content);splitter.setSizes([270, 920])
            settings = QHBoxLayout();right.addLayout(settings)
            self.audio_label = QLabel();settings.addWidget(self.audio_label)
            self.audio = QComboBox()
            for label, code in [('Español', 'es'), ('English', 'en'), ('Português', 'pt'), ('Français', 'fr'), ('Deutsch', 'de'), ('Italiano', 'it'), ('日本語', 'ja'), ('中文', 'zh'), ('Auto', '')]:
                self.audio.addItem(label, code)
            self.audio.setCurrentIndex(max(0, self.audio.findData(store.setting('audio_language', 'es'))));settings.addWidget(self.audio)
            self.model_label = QLabel();settings.addWidget(self.model_label)
            self.model = QComboBox();self.model.addItems(['small', 'medium', 'large-v3-turbo'])
            self.model.setCurrentText(store.setting('model', 'small'));settings.addWidget(self.model)
            button('prepare', settings, self.prepare)
            self.model_info = QLabel();self.model_info.setWordWrap(True);right.addWidget(self.model_info)
            self.terms = QLineEdit(store.setting('terms', ''));right.addWidget(self.terms)
            actions = QHBoxLayout();right.addLayout(actions)
            button('play', actions, self.play);button('relink', actions, self.relink)
            self.clock = QLabel('00:00:00');actions.addWidget(self.clock)
            self.follow = QCheckBox();self.follow.setChecked(True);actions.addWidget(self.follow)
            self.slider = QSlider(Qt.Orientation.Horizontal);self.slider.setRange(0, 0);right.addWidget(self.slider)
            self.tabs = QTabWidget();right.addWidget(self.tabs, 1)
            self.editor = QTextEdit();self.editor.setAcceptRichText(False);self.editor.setStyleSheet('font-size:16px;padding:12px;background:white;')
            self.tabs.addTab(self.editor, '')
            quote_page = QWidget();q_layout = QVBoxLayout(quote_page)
            self.quote_list = QListWidget();q_layout.addWidget(self.quote_list)
            button('quote_copy', q_layout, self.copy_quote);self.tabs.addTab(quote_page, '')
            actions2 = QHBoxLayout();right.addLayout(actions2)
            button('listen', actions2, self.listen_selection)
            self.speaker = QLineEdit();actions2.addWidget(self.speaker)
            button('save_quote', actions2, self.save_quote)
            export_row = QHBoxLayout();right.addLayout(export_row)
            button('copy', export_row, self.copy_text);button('export', export_row, self.export)
            self.export_note = QLabel();self.export_note.setWordWrap(True);right.addWidget(self.export_note)
            self.limits = QLabel();self.limits.setWordWrap(True);self.limits.setStyleSheet('color:#666;font-size:11px');outer.addWidget(self.limits)
            footer = QHBoxLayout();outer.addLayout(footer)
            self.status = QLabel();self.status.setWordWrap(True);footer.addWidget(self.status, 1)
            self.progress = QProgressBar();self.progress.setRange(0, 100);self.progress.setValue(0);self.progress.setMaximumWidth(180);footer.addWidget(self.progress)
            button('cancel', footer, self.cancel)
            self.media = QMediaPlayer(self);self.output = QAudioOutput(self);self.media.setAudioOutput(self.output)
            self.media.positionChanged.connect(self.position)
            self.media.durationChanged.connect(lambda duration:self.slider.setRange(0, duration))
            self.media.errorOccurred.connect(lambda *_:self.status.setText(self.media.errorString()))
            self.slider.sliderReleased.connect(lambda:self.media.setPosition(self.slider.value()))
            self.list.currentItemChanged.connect(self.selection_changed)
            self.editor.textChanged.connect(self.edit_changed)
            self.interface.currentIndexChanged.connect(self.change_language)
            self.audio.currentIndexChanged.connect(lambda:store.set_setting('audio_language', self.audio.currentData()))
            self.model.currentTextChanged.connect(self.model_changed)
            self.terms.textChanged.connect(lambda value:store.set_setting('terms', value))
            self.edit_timer = QTimer(self);self.edit_timer.setSingleShot(True);self.edit_timer.setInterval(250);self.edit_timer.timeout.connect(self.flush_edit)
            self.poller = QTimer(self);self.poller.setInterval(200);self.poller.timeout.connect(self.poll);self.poller.start()
            self.retranslate();self.refresh();self.set_busy(False)
            self.status.setText(self.t('welcome'))
            self.setStyleSheet('QMainWindow{background:#f7f7fb} QPushButton{padding:7px} QLineEdit,QComboBox{padding:5px} QListWidget{background:white;border:1px solid #ddd;border-radius:6px} QTabWidget::pane{border:1px solid #ddd}')

        def t(self, key):
            return (ES if self.language == 'es' else EN).get(key, key)

        def retranslate(self):
            self.setWindowTitle(self.t('title'))
            for key, obj in self.buttons.items():obj.setText(self.t(key))
            self.interface_label.setText(self.t('interface'));self.audio_label.setText(self.t('language'));self.model_label.setText(self.t('model'))
            self.model_info.setText(self.t('model_info'));self.terms.setPlaceholderText(self.t('terms'));self.speaker.setPlaceholderText(self.t('speaker'))
            self.follow.setText(self.t('follow'));self.tabs.setTabText(0, self.t('text'));self.tabs.setTabText(1, self.t('quotes'))
            self.export_note.setText(self.t('export_note'));self.limits.setText(self.t('limitations'))

        def change_language(self):
            self.language = self.interface.currentData();store.set_setting('ui_language', self.language)
            self.retranslate();self.refresh(self.selected)

        def model_changed(self):
            store.set_setting('model', self.model.currentText())

        def set_busy(self, busy):
            for key in ['add','folder','run','prepare','remove','undo','relink']:
                self.buttons[key].setEnabled(not busy)
            self.buttons['cancel'].setEnabled(busy)
            for item in (self.audio, self.model, self.terms):item.setEnabled(not busy)
            self.editor.setReadOnly(busy)
            self.buttons['save_quote'].setEnabled(not busy)

        def refresh(self, selected=None):
            selected = selected or self.selected
            self.list.blockSignals(True);self.list.clear()
            target = None
            for doc in store.documents():
                row = QListWidgetItem(doc['name'] + '\n' + self.t(doc['status']))
                row.setData(Qt.ItemDataRole.UserRole, doc['id']);self.list.addItem(row)
                if doc['id'] == selected:target = row
            if target is None and self.list.count():target = self.list.item(0)
            self.list.setCurrentItem(target);self.list.blockSignals(False)
            self.selection_changed(target, None)

        def selection_changed(self, item, previous):
            self.flush_edit()
            ident = item.data(Qt.ItemDataRole.UserRole) if item else None
            if ident != self.selected:
                self.media.stop();self.loaded_source = None;self.play_until = None
            self.selected = ident
            doc = store.get(ident) if ident else None
            self.editor.blockSignals(True);self.editor.setPlainText(doc['text'] if doc else '');self.editor.blockSignals(False)
            self.editor.setExtraSelections([]);self.last_highlight = None
            self.quote_list.clear()
            for quote in (doc or {}).get('quotes', []):
                self.quote_list.addItem(f"{quote.get('speaker','')} · {timestamp(quote['start'])}\n{quote['text']}")

        def edit_changed(self):
            if self.selected:
                self.pending_edit = (self.selected, self.editor.toPlainText());self.edit_timer.start()

        def flush_edit(self):
            pending = self.pending_edit;self.pending_edit = None
            if pending:
                doc = store.get(pending[0])
                if doc:
                    doc['text'] = pending[1];store.save(doc)

        def add_files(self):
            paths, _ = QFileDialog.getOpenFileNames(self, self.t('add'), '', 'Audio/video (*.mp3 *.mp4 *.mov *.m4a *.wav *.flac *.aac *.aiff *.aif *.caf *.m4v)')
            if paths:self.launch({'task':'scan', 'inputs':paths})

        def add_folder(self):
            path = QFileDialog.getExistingDirectory(self, self.t('folder'))
            if path:self.launch({'task':'scan', 'inputs':[path]})

        def prepare(self):
            self.launch({'task':'prepare', 'model':self.model.currentText()})

        def begin(self):
            self.flush_edit()
            if not (root / 'Models' / (self.model.currentText() + '.ready')).exists():
                self.status.setText(self.t('model_missing'));return
            self.queue = deque(d['id'] for d in store.documents() if not d.get('complete'))
            self.next_job()

        def next_job(self):
            while self.queue:
                ident = self.queue.popleft();doc = store.get(ident)
                if not doc:continue
                doc['status'] = 'running';doc['segments'] = [];doc['text'] = '';store.save(doc)
                self.refresh(ident)
                self.launch({'task':'transcribe', 'id':ident, 'source':doc['source'], 'model':self.model.currentText(),
                             'language':self.audio.currentData(), 'terms':[t.strip()[:100] for t in self.terms.text().split(',') if t.strip()][:100]})
                return
            self.set_busy(False);self.status.setText(self.t('finished'))

        def launch(self, job):
            if self.proc:return
            self.flush_edit();self.media.stop();self.cancelled = False;self.event_error = ''
            self.job_dir = Path(tempfile.mkdtemp(prefix='job-', dir=root))
            job['models'] = str(root / 'Models');atomic_json(self.job_dir / 'job.json', job)
            self.job = job;self.events_offset = 0;self.started = time.monotonic()
            self.set_busy(True);self.progress.setRange(0,0)
            self.status.setText(self.t('scanning' if job['task'] == 'scan' else 'preparing' if job['task'] == 'prepare' else 'loading'))
            try:
                self.proc = subprocess.Popen(command(self.job_dir / 'job.json'), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                             creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0) if sys.platform=='win32' else 0)
            except Exception as error:
                self.event_error = str(error);self.finish(1)

        def poll(self):
            if not self.proc:return
            self.read_events()
            code = self.proc.poll()
            if code is not None:self.finish(code)
            elif time.monotonic() - self.started > (3600 if self.job['task']=='prepare' else 21600):
                self.event_error = 'Timeout';self.proc.kill()

        def read_events(self):
            events = self.job_dir / 'events.jsonl'
            if not events.exists():return
            with events.open('rb') as stream:
                stream.seek(self.events_offset)
                while True:
                    line = stream.readline()
                    if not line or not line.endswith(b'\n'):break
                    self.events_offset = stream.tell()
                    try:event = json.loads(line)
                    except (ValueError,UnicodeError):continue
                    if event['kind']=='error':self.event_error = event['message']
                    elif event['kind']=='status':self.status.setText(self.t(event['value']))
                    elif event['kind']=='segment':
                        doc = store.get(self.job.get('id'))
                        if doc:
                            doc['segments'].append(event['segment']);doc['text'] = transcript_text(doc['segments']);store.save(doc)
                            if self.selected==doc['id']:
                                self.editor.blockSignals(True);self.editor.setPlainText(doc['text']);self.editor.blockSignals(False)
                        self.progress.setRange(0,100);self.progress.setValue(int(event['progress']*100))

        def finish(self, code):
            job, folder = self.job, self.job_dir
            self.proc = None
            result_file = folder / 'result.json'
            success = code==0 and result_file.exists() and not self.cancelled
            result = None
            try:
                if success:result = json.loads(result_file.read_text(encoding='utf-8'))
            except (OSError,ValueError):success = False
            if job['task']=='scan' and success:
                known = {os.path.normcase(d['source']) for d in store.documents()}
                for path in result['files']:
                    if os.path.normcase(path) not in known:
                        store.add(new_document(path));known.add(os.path.normcase(path))
            elif job['task']=='transcribe':
                doc = store.get(job['id'])
                if doc:
                    if success:
                        doc.update(segments=result['segments'], text=transcript_text(result['segments']), language=result['language'], duration=result['duration'], complete=True, status='done')
                    else:doc['status'] = 'partial' if self.cancelled else 'error'
                    store.save(doc)
            self.progress.setRange(0,100);self.progress.setValue(100 if success else 0)
            self.refresh(self.selected);self.set_busy(False)
            self.status.setText(self.t('ready') if success and job['task']=='prepare' else self.t('saved') if success else self.t('partial') if self.cancelled else self.t('errors') + ' ' + self.event_error)
            import shutil
            shutil.rmtree(folder, ignore_errors=True)
            self.job = None;self.job_dir = None
            if job['task']=='transcribe' and not self.cancelled and self.queue:QTimer.singleShot(0, self.next_job)

        def cancel(self):
            self.queue.clear();self.cancelled = True
            if self.proc:self.proc.kill()

        def remove_doc(self):
            if self.proc or not self.selected:return
            if QMessageBox.question(self, 'Vocalia', self.t('remove_confirm')) != QMessageBox.StandardButton.Yes:return
            self.remove_id(self.selected)

        def remove_id(self, ident):
            self.flush_edit();self.media.stop();self.selected = None;store.remove(ident);self.refresh()

        def undo_remove(self):
            ident = store.undo_remove();self.refresh(ident)

        def play(self, start=None, end=None):
            doc = store.get(self.selected) if self.selected else None
            if not doc:return
            if not Path(doc['source']).is_file():self.status.setText(self.t('source_missing'));return
            if self.loaded_source != doc['source']:
                self.media.setSource(QUrl.fromLocalFile(doc['source']));self.loaded_source = doc['source']
            if isinstance(start, bool):start = None
            if start is None and self.media.playbackState()==QMediaPlayer.PlaybackState.PlayingState:
                self.media.pause();return
            if start is not None:self.media.setPosition(round(start*1000))
            self.play_until = end;self.media.play()

        def position(self, ms):
            self.clock.setText(timestamp(ms/1000)[:-4])
            if not self.slider.isSliderDown():self.slider.setValue(ms)
            if self.play_until is not None and ms>=self.play_until*1000:
                self.media.pause();self.play_until = None
            doc = store.get(self.selected) if self.selected else None
            if not doc or self.loaded_source != doc['source']:return
            doc['text'] = self.editor.toPlainText()
            active = playback_range(doc, ms/1000)
            if active == self.last_highlight:return
            self.last_highlight = active;selections = []
            if active:
                selected = QTextEdit.ExtraSelection();cursor = QTextCursor(self.editor.document())
                cursor.setPosition(qt_index(doc['text'], active[0]));cursor.setPosition(qt_index(doc['text'], active[1]), QTextCursor.MoveMode.KeepAnchor)
                selected.cursor = cursor;selected.format.setBackground(QColor('#ffedaa'));selections.append(selected)
                if self.follow.isChecked() and not self.editor.textCursor().hasSelection():
                    bar = self.editor.verticalScrollBar();rect = self.editor.cursorRect(cursor)
                    if rect.bottom()>self.editor.viewport().height() or rect.top()<0:bar.setValue(bar.value()+rect.top()-self.editor.viewport().height()//3)
            self.editor.setExtraSelections(selections)

        def match(self):
            self.flush_edit();doc = store.get(self.selected) if self.selected else None
            if not doc:return None
            cursor = self.editor.textCursor()
            return selection_match(doc, python_index(doc['text'],cursor.selectionStart()), python_index(doc['text'],cursor.selectionEnd()))

        def listen_selection(self):
            match = self.match()
            if match:self.play(match['start'], match['end'])
            else:self.status.setText(self.t('invalid_selection'))

        def save_quote(self):
            match = self.match();doc = store.get(self.selected) if self.selected else None
            if not match or not doc:self.status.setText(self.t('invalid_selection'));return
            match.update(speaker=self.speaker.text(), source=doc['name'])
            doc['quotes'].append(match);store.save(doc);self.refresh(doc['id']);self.status.setText(self.t('saved'))

        def copy_quote(self):
            doc = store.get(self.selected) if self.selected else None;index = self.quote_list.currentRow()
            if not doc or not 0<=index<len(doc['quotes']):return
            q = doc['quotes'][index]
            app.clipboard().setText(f"{q['text']}\n\n{q.get('speaker','')} · {q['source']} · {timestamp(q['start'])}–{timestamp(q['end'])}")
            self.status.setText(self.t('copied'))

        def copy_text(self):
            app.clipboard().setText(self.editor.toPlainText());self.status.setText(self.t('copied'))

        def export(self):
            self.flush_edit();doc = store.get(self.selected) if self.selected else None
            if not doc:return
            name, filter_used = QFileDialog.getSaveFileName(self, self.t('export'), Path(doc['name']).stem+'.txt', 'Text (*.txt);;SubRip (*.srt);;WebVTT (*.vtt)')
            if name:
                kind = 'srt' if '*.srt' in filter_used else 'vtt' if '*.vtt' in filter_used else 'txt'
                path = Path(name)
                if path.suffix.lower() not in ('.txt','.srt','.vtt'):path = path.with_suffix('.'+kind)
                try:path.write_text(export_text(doc,kind),encoding='utf-8');self.status.setText(self.t('saved'))
                except OSError as error:QMessageBox.warning(self,'Vocalia',str(error))

        def export_all(self):
            self.flush_edit();folder = QFileDialog.getExistingDirectory(self,self.t('batch_export'))
            if not folder:return
            try:
                for doc in store.documents():
                    if not doc['text']:continue
                    name = Path(doc['name']).stem;index = 0
                    while True:
                        target = Path(folder)/(name+('' if index==0 else f' ({index})')+'.txt')
                        try:
                            with target.open('x',encoding='utf-8') as stream:stream.write(doc['text'])
                            break
                        except FileExistsError:index += 1
                self.status.setText(self.t('saved'))
            except OSError as error:QMessageBox.warning(self,'Vocalia',str(error))

        def relink(self):
            doc = store.get(self.selected) if self.selected else None
            if not doc:return
            path,_ = QFileDialog.getOpenFileName(self,self.t('relink'))
            if path:
                self.media.stop();doc['source'] = str(Path(path).resolve());store.save(doc);self.loaded_source = None

        def closeEvent(self, event):
            if self.proc:
                if QMessageBox.question(self,'Vocalia',self.t('close_confirm')) != QMessageBox.StandardButton.Yes:
                    event.ignore();return
                self.cancel()
                try:self.proc.wait(timeout=5)
                except subprocess.TimeoutExpired:event.ignore();return
                self.read_events();self.finish(self.proc.returncode)
            self.flush_edit();self.media.stop();store.close();lock.unlock();event.accept()

    window = Window()
    window.show()
    if smoke:
        def test_gui():
            try:
                a = new_document('synthetic.wav');a.update(text='Hello world.',segments=[dict(start=0,end=2,text='Hello world.')],complete=True,status='done')
                b = new_document('second.wav')
                store.add(a);store.add(b);window.refresh(a['id'])
                window.pending_edit = (a['id'], 'Edited quote')
                window.remove_id(a['id'])
                window.pending_edit = (a['id'], 'Stale callback');window.flush_edit()
                assert store.get(b['id'])['text']=='' and store.get(a['id']) is None
                window.remove_id(b['id']);assert not store.documents()
                window.undo_remove();assert len(store.documents())==1
                window.interface.setCurrentIndex(1);assert window.buttons['add'].text()=='Add files'
                window.interface.setCurrentIndex(0);assert window.buttons['add'].text()=='Agregar archivos'
                # Check recovery from an abruptly terminated worker and from cancellation.
                failed = new_document('missing.mp3');failed['status'] = 'running';store.add(failed)
                for cancelled in (False, True):
                    window.job_dir = Path(tempfile.mkdtemp(prefix='failure-', dir=root))
                    window.job = {'task':'transcribe', 'id':failed['id']}
                    window.cancelled = cancelled;window.finish(-1)
                    assert store.get(failed['id'])['status'] == ('partial' if cancelled else 'error')
                    assert window.buttons['add'].isEnabled() and window.proc is None
                # Real child process remains usable after the failed job; Unicode paths survive.
                folder = root / 'Entrevistas José';folder.mkdir()
                (folder / 'declaración.mp3').write_bytes(b'test')
                window.launch({'task':'scan', 'inputs':[str(folder)]})
                deadline = time.monotonic() + 30
                while window.proc and time.monotonic() < deadline:
                    app.processEvents();time.sleep(0.01)
                assert window.proc is None and any(d['name']=='declaración.mp3' for d in store.documents())
                (root / 'GUI-PASS').write_text('PASS')
                if os.environ.get('VOCALIA_SMOKE_RESULT'):Path(os.environ['VOCALIA_SMOKE_RESULT']).write_text('PASS')
                window.close();app.exit(0)
            except Exception:
                import traceback
                traceback.print_exc();app.exit(1)
        QTimer.singleShot(200, test_gui)
    return app.exec()


if __name__ == '__main__':
    import multiprocessing
    multiprocessing.freeze_support()
    if len(sys.argv)>2 and sys.argv[1]=='--worker':
        from engine import run
        sys.exit(run(sys.argv[2]))
    sys.exit(main('--smoke-test' in sys.argv))
